using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class PageManager : MonoBehaviour
{
    [Header("所有页面")]
    public GameObject homePage;
    public GameObject forestPage;
    public GameObject riverPage; 
    public GameObject mountainPage;  // 新增山脉页面
    public GameObject cavePage;
    public GameObject creditsPage;

    [Header("音频组件")]
    public AudioSource backgroundMusic;
    public AudioSource narrationSource;
    public Slider volumeSlider;

    private int currentPageIndex = 0;
    private GameObject[] allPages;

    void Start()
    {
        // 收集所有页面到数组 - 更新顺序
        allPages = new GameObject[] { homePage, forestPage, riverPage, mountainPage, cavePage, creditsPage };
        
        // 开始时只显示首页
        ShowPage(0);
        
        // 设置音量控制
        SetupAudio();
    }

    // 显示指定页面
    public void ShowPage(int pageIndex)
    {
        // 隐藏所有页面
        foreach (GameObject page in allPages)
        {
            if (page != null)
                page.SetActive(false);
        }
        
        // 显示目标页面
        if (pageIndex >= 0 && pageIndex < allPages.Length && allPages[pageIndex] != null)
        {
            allPages[pageIndex].SetActive(true);
            currentPageIndex = pageIndex;
        }
    }

    // 下一页
    public void NextPage()
    {
        if (currentPageIndex < allPages.Length - 1)
        {
            ShowPage(currentPageIndex + 1);
        }
    }

    // 上一页
    public void PreviousPage()
    {
        if (currentPageIndex > 0)
        {
            ShowPage(currentPageIndex - 1);
        }
    }

    // 显示首页
    public void ShowHomePage()
    {
        ShowPage(0);
    }

    // 显示森林页
    public void ShowForestPage()
    {
        ShowPage(1);
    }

    // 显示河流页
    public void ShowRiverPage()
    {
        ShowPage(2);
    }

    // 显示山脉页 - 新增
    public void ShowMountainPage()
    {
        ShowPage(3);
    }

    // 显示洞穴页
    public void ShowCavePage()
    {
        ShowPage(4);
    }

    // 显示致谢页
    public void ShowCreditsPage()
    {
        ShowPage(5);
    }

    // 音频设置
    private void SetupAudio()
    {
        if (volumeSlider != null)
        {
            volumeSlider.onValueChanged.AddListener(SetVolume);
            volumeSlider.gameObject.SetActive(false);
        }
    }

    // 音量控制
    public void ToggleVolumeSlider()
    {
        if (volumeSlider != null)
        {
            volumeSlider.gameObject.SetActive(!volumeSlider.gameObject.activeInHierarchy);
        }
    }

    public void SetVolume(float volume)
    {
        if (backgroundMusic != null)
            backgroundMusic.volume = volume;
        if (narrationSource != null)
            narrationSource.volume = volume;
    }

    // 播放旁白
    public void PlayNarration(AudioClip clip)
    {
        if (narrationSource != null && clip != null)
        {
            narrationSource.clip = clip;
            narrationSource.Play();
        }
    }
}