using UnityEngine;

public class SimpleAnimalInteraction : MonoBehaviour
{
    public Animation animalAnimation;
    public AnimationClip idleClip;
    public AnimationClip actionClip;
    
    void Start()
    {
        if (animalAnimation == null)
            animalAnimation = GetComponent<Animation>();
            
        if (animalAnimation != null && idleClip != null)
        {
            animalAnimation.clip = idleClip;
            animalAnimation.Play();
        }
    }
    
    void OnMouseDown()
    {
        if (animalAnimation != null && actionClip != null)
        {
            animalAnimation.clip = actionClip;
            animalAnimation.Play();
            
            // 播放完成后回到空闲状态
            Invoke("ReturnToIdle", actionClip.length);
        }
    }
    
    void ReturnToIdle()
    {
        if (animalAnimation != null && idleClip != null)
        {
            animalAnimation.clip = idleClip;
            animalAnimation.Play();
        }
    }
}