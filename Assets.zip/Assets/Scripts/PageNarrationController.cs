using UnityEngine;

public class PageNarrationController : MonoBehaviour
{
    public AudioSource audioSource;

    [Header("旁白音频 Clips")]
    public AudioClip forestNarration;
    public AudioClip riverNarration;
    public AudioClip moutainNarration;
    public AudioClip caveNarration;
    public AudioClip creditsNarration;

    [Header("页面对象")]
    public GameObject HomePage;
    public GameObject ForestPage;
    public GameObject RiverPage;
    public GameObject MoutainPage;
    public GameObject CavePage;
    public GameObject CreditsPage;

    private AudioClip currentClip;

    void Update()
    {
        if (ForestPage.activeSelf)
        {
            PlayNarration(forestNarration);
        }
        else if (RiverPage.activeSelf)
        {
            PlayNarration(riverNarration);
        }
        else if (MoutainPage.activeSelf)
        {
            PlayNarration(moutainNarration);
        }
        else if (CavePage.activeSelf)
        {
            PlayNarration(caveNarration);
        }
        else if (CreditsPage.activeSelf)
        {
            PlayNarration(creditsNarration);
        }
        else if (HomePage.activeSelf)
        {
            StopNarration();  // 首页不播放旁白
        }
    }

    private void PlayNarration(AudioClip clip)
    {
        if (clip != null && audioSource != null)
        {
            // 避免重复播放同一音频
            if (audioSource.clip != clip)
            {
                audioSource.clip = clip;
                audioSource.Play();
                currentClip = clip;
            }
        }
    }

    private void StopNarration()
    {
        if (audioSource != null && audioSource.isPlaying)
        {
            audioSource.Stop();
            currentClip = null;
        }
    }
}
