using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class FoxAnimationManager : MonoBehaviour
{
    [Header("三个页面的狐狸按钮")]
    public Button forestFoxButton;    // 森林狐狸 - 探索动作
    public Button riverFoxButton;     // 河流狐狸 - 喝水动作  
    public Button mountainFoxButton;  // 山脉狐狸 - 眺望动作

    [Header("动画参数")]
    public float animationSpeed = 1f;
    private bool isAnimating = false;

    // 保存原始状态
    private Vector3[] originalPositions = new Vector3[3];
    private Vector3[] originalScales = new Vector3[3];
    private Quaternion[] originalRotations = new Quaternion[3];

    void Start()
    {
        // 保存所有狐狸的原始状态
        SaveOriginalStates();
        
        // 绑定按钮事件
        if (forestFoxButton != null)
            forestFoxButton.onClick.AddListener(() => StartCoroutine(ForestFoxAnimation()));
        if (riverFoxButton != null)
            riverFoxButton.onClick.AddListener(() => StartCoroutine(RiverFoxAnimation()));
        if (mountainFoxButton != null)
            mountainFoxButton.onClick.AddListener(() => StartCoroutine(MountainFoxAnimation()));
    }

    void SaveOriginalStates()
    {
        Button[] foxButtons = { forestFoxButton, riverFoxButton, mountainFoxButton };
        
        for (int i = 0; i < foxButtons.Length; i++)
        {
            if (foxButtons[i] != null)
            {
                RectTransform rect = foxButtons[i].GetComponent<RectTransform>();
                originalPositions[i] = rect.anchoredPosition;
                originalScales[i] = rect.localScale;
                originalRotations[i] = rect.rotation;
            }
        }
    }

    // 森林狐狸动画 - 探索行为
    private IEnumerator ForestFoxAnimation()
    {
        if (isAnimating) yield break;
        isAnimating = true;

        RectTransform foxRect = forestFoxButton.GetComponent<RectTransform>();
        Vector3 originalPos = originalPositions[0];
        
        Debug.Log("森林狐狸：开始探索周围环境");

        // 动画序列：嗅探 → 左右张望 → 小步走动
        yield return StartCoroutine(SniffAnimation(foxRect, originalPos));
        yield return new WaitForSeconds(0.2f);
        yield return StartCoroutine(LookAroundAnimation(foxRect, originalPos));
        yield return new WaitForSeconds(0.2f);
        yield return StartCoroutine(WalkAnimation(foxRect, originalPos));

        // 确保恢复原状
        ResetFoxState(foxRect, 0);
        isAnimating = false;
    }

    // 河流狐狸动画 - 喝水行为
    private IEnumerator RiverFoxAnimation()
    {
        if (isAnimating) yield break;
        isAnimating = true;

        RectTransform foxRect = riverFoxButton.GetComponent<RectTransform>();
        Vector3 originalPos = originalPositions[1];
        
        Debug.Log("河流狐狸：在河边喝水");

        // 动画序列：低头 → 喝水 → 抬头
        yield return StartCoroutine(BowHeadAnimation(foxRect, originalPos));
        yield return new WaitForSeconds(0.5f); // 喝水时间
        yield return StartCoroutine(RaiseHeadAnimation(foxRect, originalPos));
        yield return StartCoroutine(ShakeWaterAnimation(foxRect, originalPos));

        ResetFoxState(foxRect, 1);
        isAnimating = false;
    }

    // 山脉狐狸动画 - 眺望行为
    private IEnumerator MountainFoxAnimation()
    {
        if (isAnimating) yield break;
        isAnimating = true;

        RectTransform foxRect = mountainFoxButton.GetComponent<RectTransform>();
        Vector3 originalPos = originalPositions[2];
        
        Debug.Log("山脉狐狸：眺望远方的风景");

        // 动画序列：站立 → 瞭望 → 坐下
        yield return StartCoroutine(StandUpAnimation(foxRect, originalPos));
        yield return new WaitForSeconds(0.3f);
        yield return StartCoroutine(LookFarAnimation(foxRect, originalPos));
        yield return new WaitForSeconds(0.5f);
        yield return StartCoroutine(SitDownAnimation(foxRect, originalPos));

        ResetFoxState(foxRect, 2);
        isAnimating = false;
    }

    // === 具体动画方法 ===

    // 嗅探动画
    private IEnumerator SniffAnimation(RectTransform fox, Vector3 originalPos)
    {
        float duration = 0.8f;
        float elapsed = 0f;
        
        while (elapsed < duration)
        {
            float sniff = Mathf.Sin(elapsed * 8f) * 5f; // 快速上下移动模拟嗅探
            fox.anchoredPosition = originalPos + Vector3.up * sniff;
            elapsed += Time.deltaTime;
            yield return null;
        }
        fox.anchoredPosition = originalPos;
    }

    // 张望动画
    private IEnumerator LookAroundAnimation(RectTransform fox, Vector3 originalPos)
    {
        // 左右转头
        float duration = 1f;
        float elapsed = 0f;
        
        while (elapsed < duration)
        {
            float rotation = Mathf.Sin(elapsed * 4f) * 15f; // 左右旋转
            fox.rotation = Quaternion.Euler(0, 0, rotation);
            elapsed += Time.deltaTime;
            yield return null;
        }
        fox.rotation = Quaternion.identity;
    }

    // 走路动画
    private IEnumerator WalkAnimation(RectTransform fox, Vector3 originalPos)
    {
        float duration = 1f;
        float elapsed = 0f;
        
        while (elapsed < duration)
        {
            // 模拟走路：位置移动 + 轻微上下浮动
            float walkOffset = Mathf.Sin(elapsed * 6f) * 20f;
            float bounce = Mathf.Abs(Mathf.Sin(elapsed * 12f)) * 5f;
            
            fox.anchoredPosition = originalPos + new Vector3(walkOffset, bounce, 0);
            elapsed += Time.deltaTime;
            yield return null;
        }
        fox.anchoredPosition = originalPos;
    }

    // 低头动画
    private IEnumerator BowHeadAnimation(RectTransform fox, Vector3 originalPos)
    {
        float duration = 0.5f;
        float elapsed = 0f;
        
        while (elapsed < duration)
        {
            fox.anchoredPosition = originalPos + Vector3.down * 15f;
            fox.rotation = Quaternion.Euler(0, 0, -10f); // 头部稍微倾斜
            elapsed += Time.deltaTime;
            yield return null;
        }
    }

    // 抬头动画
    private IEnumerator RaiseHeadAnimation(RectTransform fox, Vector3 originalPos)
    {
        float duration = 0.3f;
        float elapsed = 0f;
        
        while (elapsed < duration)
        {
            fox.anchoredPosition = Vector3.Lerp(fox.anchoredPosition, originalPos, elapsed/duration);
            fox.rotation = Quaternion.Lerp(fox.rotation, Quaternion.identity, elapsed/duration);
            elapsed += Time.deltaTime;
            yield return null;
        }
    }

    // 甩水动画
    private IEnumerator ShakeWaterAnimation(RectTransform fox, Vector3 originalPos)
    {
        float duration = 0.6f;
        float elapsed = 0f;
        
        while (elapsed < duration)
        {
            float shake = Mathf.Sin(elapsed * 20f) * 8f; // 快速抖动
            fox.anchoredPosition = originalPos + Vector3.right * shake;
            elapsed += Time.deltaTime;
            yield return null;
        }
        fox.anchoredPosition = originalPos;
    }

    // 站立动画
    private IEnumerator StandUpAnimation(RectTransform fox, Vector3 originalPos)
    {
        float duration = 0.4f;
        float elapsed = 0f;
        
        while (elapsed < duration)
        {
            fox.localScale = Vector3.Lerp(originalScales[2], originalScales[2] * 1.1f, elapsed/duration);
            elapsed += Time.deltaTime;
            yield return null;
        }
    }

    // 瞭望动画
    private IEnumerator LookFarAnimation(RectTransform fox, Vector3 originalPos)
    {
        float duration = 1f;
        float elapsed = 0f;
        
        while (elapsed < duration)
        {
            // 轻微的身体起伏，模拟呼吸和专注
            float breath = Mathf.Sin(elapsed * 4f) * 2f;
            fox.anchoredPosition = originalPos + Vector3.up * breath;
            elapsed += Time.deltaTime;
            yield return null;
        }
    }

    // 坐下动画
    private IEnumerator SitDownAnimation(RectTransform fox, Vector3 originalPos)
    {
        float duration = 0.4f;
        float elapsed = 0f;
        
        while (elapsed < duration)
        {
            fox.localScale = Vector3.Lerp(fox.localScale, originalScales[2], elapsed/duration);
            elapsed += Time.deltaTime;
            yield return null;
        }
        fox.localScale = originalScales[2];
    }

    // 重置狐狸状态
    private void ResetFoxState(RectTransform fox, int index)
    {
        fox.anchoredPosition = originalPositions[index];
        fox.localScale = originalScales[index];
        fox.rotation = originalRotations[index];
    }
}