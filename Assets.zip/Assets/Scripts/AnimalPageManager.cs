using UnityEngine;
using UnityEngine.UI;

public class AnimalPageManager : MonoBehaviour
{
    [Header("动物页面")]
    public GameObject[] animalPages; // 狐狸、鱼、鸟的页面
    
    [Header("导航按钮")]
    public Button[] navButtons; // 对应三个动物的导航按钮
    
    [Header("当前动物")]
    public int currentAnimalIndex = 0;

    void Start()
    {
        // 设置导航按钮事件
        SetupNavigation();
        
        // 显示初始页面
        ShowAnimalPage(currentAnimalIndex);
    }

    void SetupNavigation()
    {
        if (navButtons == null || navButtons.Length == 0) return;
        
        for (int i = 0; i < navButtons.Length; i++)
        {
            int index = i; // 重要：创建局部变量
            if (navButtons[i] != null)
            {
                navButtons[i].onClick.AddListener(() => SwitchToAnimal(index));
            }
        }
    }

    public void SwitchToAnimal(int animalIndex)
    {
        // 隐藏所有页面
        foreach (GameObject page in animalPages)
        {
            if (page != null)
                page.SetActive(false);
        }
        
        // 显示选中页面
        if (animalIndex >= 0 && animalIndex < animalPages.Length && animalPages[animalIndex] != null)
        {
            animalPages[animalIndex].SetActive(true);
            currentAnimalIndex = animalIndex;
        }
        
        // 更新按钮状态（可选：高亮当前选中的按钮）
        UpdateButtonStates(animalIndex);
    }

    void UpdateButtonStates(int activeIndex)
    {
        for (int i = 0; i < navButtons.Length; i++)
        {
            if (navButtons[i] != null)
            {
                // 可选：更改按钮颜色来表示当前选中的页面
                ColorBlock colors = navButtons[i].colors;
                colors.normalColor = (i == activeIndex) ? Color.yellow : Color.white;
                navButtons[i].colors = colors;
            }
        }
    }

    void ShowAnimalPage(int index)
    {
        SwitchToAnimal(index);
    }
}