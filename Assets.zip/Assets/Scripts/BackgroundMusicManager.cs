using UnityEngine;
using UnityEngine.UI;

public class BackgroundMusicManager : MonoBehaviour
{
    [Header("背景音乐")]
    public AudioClip backgroundMusic;
    
    [Header("UI组件")]
    public Button musicToggleButton;
    public Image musicButtonIcon;
    public Sprite musicOnSprite;
    public Sprite musicOffSprite;
    
    private AudioSource musicSource;
    private bool isMusicOn = true;

    void Start()
    {
        // 创建音频源
        musicSource = gameObject.AddComponent<AudioSource>();
        musicSource.clip = backgroundMusic;
        musicSource.loop = true;
        musicSource.volume = 0.5f;
        
        // 设置按钮事件
        if (musicToggleButton != null)
        {
            musicToggleButton.onClick.AddListener(ToggleMusic);
        }
        
        // 加载设置
        isMusicOn = PlayerPrefs.GetInt("MusicOn", 1) == 1;
        ApplyMusicSetting();
    }

    public void ToggleMusic()
    {
        isMusicOn = !isMusicOn;
        ApplyMusicSetting();
        SaveSetting();
    }

    void ApplyMusicSetting()
    {
        if (isMusicOn)
        {
            musicSource.Play();
            if (musicButtonIcon != null)
            {
                musicButtonIcon.sprite = musicOnSprite;
            }
        }
        else
        {
            musicSource.Stop();
            if (musicButtonIcon != null)
            {
                musicButtonIcon.sprite = musicOffSprite;
            }
        }
    }

    void SaveSetting()
    {
        PlayerPrefs.SetInt("MusicOn", isMusicOn ? 1 : 0);
        PlayerPrefs.Save();
    }
}